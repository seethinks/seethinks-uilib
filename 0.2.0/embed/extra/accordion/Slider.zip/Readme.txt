Custom AS3 Slider
Created by Carlos Yanez
ActiveTuts+ Exclusive Freebie

AS3 powered Slider for your applications
Use this Slider with any project you like!

This Slider includes the following options:

-Custom minimum range
-Custom maximum range
-Clean & good looking skin
-Show's current value

Usage:

Drag the source MovieClip and the Main.as file to your project folder and edit the desired options.

Use it in your projects!